 
	<link rel="stylesheet" type="text/css" href="BS/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="BS/css/all.css">
	<link rel="stylesheet" type="text/css" href="BS/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="BS/css/fontawesome.min.css">
	<link rel="stylesheet" type="text/css" href="BS/js/all.js">

	<script   type="text/javascript" src="BS/jquery-3.4.1.js"> </script>
 
    <script   type="text/javascript" src="BS/popper.js"> </script>

    <script   type="text/javascript" src="BS/bootstrap.min.js"> </script>
