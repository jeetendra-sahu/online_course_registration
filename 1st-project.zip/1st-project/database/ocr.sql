-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2020 at 11:34 AM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ocr`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(128) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `creation_date`) VALUES
(1, 'Jeetendra sahu', 'sahujeetendra06@gmail.com', '123456', '2020-04-18 01:01:26');

-- --------------------------------------------------------

--
-- Table structure for table `availablecourses`
--

CREATE TABLE `availablecourses` (
  `course_id` int(50) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mode` varchar(50) NOT NULL,
  `duration` varchar(500) NOT NULL,
  `price` int(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `manual` varchar(50) NOT NULL,
  `teacher` varchar(50) NOT NULL,
  `admin` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `availablecourses`
--

INSERT INTO `availablecourses` (`course_id`, `name`, `mode`, `duration`, `price`, `image`, `description`, `manual`, `teacher`, `admin`) VALUES
(1, 'HTML', 'online', '90 days', 900, 'html.jpg', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'html.pdf', 'jeetendra sahu', 1),
(3, 'CSS FULL COURSE', 'online', '60 days', 1500, 'css.jpg', 'lorem ispum dsh jkhd kjhd kjsd mnnxcuyyu ndsbcn mnks yy hjjhsanm jsdkcjnmdcm  kjwdj jkdwn kjnjke jkedhjk kjjndnm kjndjn,m jndm,,msddkjkjdw kkew  klsdk kjdwkj msdnm mnsdc ,sdmc sd ', 'css.jpg', 'Jeetendra sahu', 1),
(4, 'MYSQL FULL COURSE', 'online', '90 days', 1000, 'mysql.jpg', 'adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dict adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dict', 'mysql.pdf', 'jeetendra sahu', 1),
(5, 'BOOTSTRAP FULL COURSE', 'online', '120 DAYS', 1500, 'bootstrap.png', 'adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nuadipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nu', 'bootstrap.pdf', 'jeetendra sahu', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` bigint(15) NOT NULL,
  `query` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `mobile`, `query`) VALUES
(1, 'jeetendra sahu', 'sahujeetendra@gmail.com', 96449935312, 'thank you jeetendra your have done realy nice work;lpppp'),
(2, 'jeetendra', 'sahu@gmail.com', 55555555, 'ssasakjdpokll;kcllllllllllllllllllllllllllllllllllllllllllllllll');

-- --------------------------------------------------------

--
-- Table structure for table `coupan`
--

CREATE TABLE `coupan` (
  `id` int(50) NOT NULL,
  `course` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `offer` varchar(10) NOT NULL,
  `valid` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coupan`
--

INSERT INTO `coupan` (`id`, `course`, `code`, `offer`, `valid`) VALUES
(1, 'HTML', 'HTML0000', '40', '2020-04-15'),
(2, 'CSS', 'CSS0000', '45', '2020-04-16'),
(3, 'boostrap', 'BOOTSTRAP0000', '50', '2020-04-17'),
(4, 'PHP', 'PHP0000', '55', '2020-04-20'),
(5, 'Msql', 'MSQL000', '35', '2020-04-18');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_form`
--

CREATE TABLE `feedback_form` (
  `id` int(11) NOT NULL,
  `user_id` int(20) NOT NULL,
  `about` int(20) NOT NULL,
  `query` varchar(95) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `password`) VALUES
(3, 'sahujeetendra@gmail.com', '202cb962ac59075b964b07152d234b70'),
(4, 'sahu@gmail.com', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(5) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` char(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `mobile` bigint(12) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `image` varchar(128) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `email`, `password`, `mobile`, `dob`, `gender`, `image`, `creation_date`) VALUES
(3, 'jeetendra sahu', 'sahujeetendra@gmail.com', '202cb962ac59075b964b07152d234b70', 9644993531, '04-08-1994', 'male', 'hellji.jpg', '2016-09-28 16:00:04'),
(4, 'purushottam', 'sahu@gmail.com', '202cb962ac59075b964b07152d234b70', 8461829490, '04-06-1996', 'male', '', '2016-09-29 16:00:04');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `name`) VALUES
(1, 'jeetendra sahu'),
(2, 'jeetendra'),
(3, ' '),
(4, 'purushottam'),
(5, 'hello'),
(6, 'mai hun kon'),
(7, 'purush');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `availablecourses`
--
ALTER TABLE `availablecourses`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `admin` (`admin`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupan`
--
ALTER TABLE `coupan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback_form`
--
ALTER TABLE `feedback_form`
  ADD PRIMARY KEY (`id`),
  ADD KEY `about` (`about`),
  ADD KEY `about_2` (`about`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `availablecourses`
--
ALTER TABLE `availablecourses`
  MODIFY `course_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `coupan`
--
ALTER TABLE `coupan`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `feedback_form`
--
ALTER TABLE `feedback_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `availablecourses`
--
ALTER TABLE `availablecourses`
  ADD CONSTRAINT `fk for course` FOREIGN KEY (`admin`) REFERENCES `admin` (`id`);

--
-- Constraints for table `feedback_form`
--
ALTER TABLE `feedback_form`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `signup` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
