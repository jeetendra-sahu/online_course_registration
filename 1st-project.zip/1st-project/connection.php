<?php 
$conn =   mysqli_connect("localhost", "root", "", "ocr") or die("connection in not done");
/*
if ($conn) {
	echo "connection is done";
} 
$sql="select * from login";
$result=mysqli_query($conn,$sql);
if (mysqli_num_rows($result)>0) {
	while ($row=mysqli_fetch_assoc($result)) {

		// print the data from data base
		echo "  id : ".$row["id"]."<br>";
		echo "email : ".$row["email"]."<br>";
		echo "password : ".$row["password"]."<br>";
	}
	
}

*/
 ?>