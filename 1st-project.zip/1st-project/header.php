<!DOCTYPE html>
<html>
<head>
	<title>Online Course Registration</title>
  
  <?php require "include.php"; ?>

<style type="text/css">
	.menu-color{
		color: yellow;
	}
	</style>	

</script>
</head>
<link rel="stylesheet" type="text/css" href="index.css">
<body>
 <div class="clearfix">
	<div  class="header">
	  <div class="top-header"> <div class="pagetext" style="text-align: right; margin-right: 10px;">
	     <?php 
	         session_start();  

        if(isset($_SESSION['id']) &&  isset($_SESSION['email']) && isset($_SESSION['password']))
            {
echo "Welcome | " .$_SESSION['email']."<a href='logout.php'  class='text-secondary'>Logout</a>". "<a href='student-dashboard.php' class='text-secondary'>Dashboard</a>";
            }
            
            else 
	          echo "Welcome |  OCR";
           ?>

	    </div></div>
		<div class="inner-header">
		 
			<div class="logo"> <a class="menu-color" href="index.php" style="font-size: 25px;">Online Course Registration</a> </div>	
         </div>
           <div class="row">
            <div class="col-lg-12">
            	<div class="link" >			 
			<h6> <a href="index.php" class="menu-color">HOME </a> </h6>
			<h6> <a href="#"  class="menu-color"> HTML</a> </h6>
			<h6> <a href="#"  class="menu-color"> CSS</a> </h6>
			<h6> <a href="#" class="menu-color"> BOOTSTRAP</a> </h6>
			<h6> <a href="#" class="menu-color"> JAVASCRIPT</a> </h6>
			<h6> <a href="#" class="menu-color"> MYSQL</a> </h6>
			<h6> <a href="#" class="menu-color">PHP</a> </h6>
			<h6> <a href="showcourses.php" class="menu-color">ALL COURSE</a> </h6>
			<h6> <a href="signup.php" class="menu-color"> SIGN UP</a> </h6>
			<h6> <a href="login.php" class="menu-color"> LOGIN</a> </h6>
			<h6> <a href="forgotpassword.php" class="menu-color"> FORGOT PASSWORD</a> </h6>
			<h6> <a href="admin.php" class="menu-color"> ADMIN</a> </h6>
            </div>
	
               </div>
			
			
		</div>
</div>
</div>
<?php  require "include.php"; ?>
</body>

</html>
