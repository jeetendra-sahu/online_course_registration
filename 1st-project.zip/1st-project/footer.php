<footer class="footer bg-info p-5" style="color: white;">
  <div class="row">
    <div class="col-sm-4  ">
    <h2><strong><u> Contact us </u></strong></h2>
      <form action="contactus.php" method="post">
      <div class="form-group">
        <input type="text"  name="name" class="form-control" placeholder="Enter your name" required>
        </div> 

   <div class="form-group">
      <input type="email" name="email" class="form-control" placeholder="Email">
      </div>

    <div class="form-group">
     <input type="number" class="form-control" name="mobile" placeholder="Enter your mobile number" required>
        </div>

        <div class="form-group">
        <textarea type="text" class="form-control" name="qeury" rows="4" placeholder="Enter your qeury " required></textarea>
        </div> 

        <input type="submit" class="btn btn-primary" name="submit" value="submit">
      </form>
    </div>
    <div class="col-sm-4 col-md-4 col-lg-4">
      <h2><strong><u>Follow on social media </u></strong></h2>
      
      <a href="#"><i class="fab fa-youtube  fa-3x text-primary " ></i></a>
      <a href="#"><i class="fab fa-facebook  fa-3x text-primary " ></i></a>
      <a href="#"><i class="fab fa-twitter fa-3x text-primary " ></i></a>
      <h1 ><u><strong>Upcoming courses</strong></u> </h1>
      <table class="table table-dark">
      <tbody>
        <tr><li>HTML </li></tr>
        <tr><li>CSS</li></tr>
        <tr><li>Javascript</li></tr>
        <tr><li>PHP</li></tr>
        <tr><li>MYSQL</li></tr>
        </tbody>
      </table>

    </div>
    <div class="col-sm-4 col-md-4 col-lg-4">
    <address>
      <h1><strong><u>Head office </u></strong></h1>
      <p>section 63 noida near utv park ,new Delhi</p>
      <h1><strong><u>Branch office</u></strong></h1>
        <p>section 63 noida near utv park ,new Delhi</p>
    </address>
    </div>
  </div>  

  </footer>

