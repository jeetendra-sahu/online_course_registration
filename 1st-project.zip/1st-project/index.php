<!DOCTYPE html>
<html>
<head>
	<title>Welcome | online course registration  </title>
<?php  require "include.php"; ?>
 <style type="text/css">

   .img-fluid{
    height: 300px;
   }
 </style>
<?php require "include.php"; ?> 
</head>
<body>
    <?php  require "header.php"; ?>
    <br><br><br>
     <!-- start courses --> 

<div class="container-fluid" id="courses">
  <div class="row">
      <div class="col-lg-6">
        <img src="image/html.jpg"  style="margin-top: 0px;"  width="100%" class="img-fluid">
      </div>
      <div class="col-lg-6">
        <h1 class="text-center"> HTML </h1><br>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente nisi atque ipsam optio, iusto explicabo odit suscipit delectus quis eum adipisci quo voluptas laboriosam quisquam sit, sint asperiores eius in! Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente nisi atque ipsam optio, iusto explicabo odit suscipit delectus quis eum adipisci quo voluptas laboriosam quisquam sit, sint asperiores eius in!
        </p>

      </div>

  </div>
  <br>
  <div class="row">
      <div class="col-lg-6">
        <h1 class="text-center text-uppercase"> CSS Style </h1><br>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente nisi atque ipsam optio, iusto explicabo odit suscipit delectus quis eum adipisci quo voluptas laboriosam quisquam sit, sint asperiores eius in! Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente nisi atque ipsam optio, iusto explicabo odit suscipit delectus quis eum adipisci quo voluptas laboriosam quisquam sit, sint asperiores eius in!</p>
      </div>
    <div class="col-lg-6">
        <img src="image/css.jpg" width="100%" class="img-fluid">
      </div>
       
  </div>
  <br>
  <div class="row">
      
      <div class="col-lg-6">
        <img src="image/bootstrap.png" width=""  class="img-fluid">
      </div>
<div class="col-lg-6">
        <h1 class="text-center text-uppercase"> BOOTSTRAP </h1><br>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente nisi atque ipsam optio, iusto explicabo odit suscipit delectus quis eum adipisci quo voluptas laboriosam quisquam sit, sint asperiores eius in! Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente nisi atque ipsam optio, iusto explicabo odit suscipit delectus quis eum adipisci quo voluptas laboriosam quisquam sit, sint asperiores eius in!</p>
      </div>
    
       
  </div>
  <br>
  <div class="row">
      <div class="col-lg-6">
        <h1 class="text-center text-uppercase"> MYSQL </h1><br>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente nisi atque ipsam optio, iusto explicabo odit suscipit delectus quis eum adipisci quo voluptas laboriosam quisquam sit, sint asperiores eius in! Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente nisi atque ipsam optio, iusto explicabo odit suscipit delectus quis eum adipisci quo voluptas laboriosam quisquam sit, sint asperiores eius in!</p>
      </div>
    <div class="col-lg-6">
        <img src="image/mysql.jpg" width="100%" class="img-fluid">
      </div>
       
  </div>
  <br><br><br>  
  <footer class="footer bg-info p-5" style="color: white;">
  <div class="row">
    <div class="col-sm-4 col-md-4 col-lg-4">
    <h2><strong><u> Contact us </u></strong></h2>
      <form class="bg-info">
        <input type="text" class="form-control" name="name" placeholder="Enter your name"><br>
        <input type="email" class="form-control" name="email" placeholder="Enter email id"><br>
        <textarea type="text" class="form-control" name="qeury" rows="5" placeholder="Enter your qeury "></textarea><br>
        <input type="submit" class="btn btn-primary" value="submit">
      </form>
    </div>
    <div class="col-sm-4 col-md-4 col-lg-4">
      <h2><strong><u>Follow on social media </u></strong></h2>
      
      <a href="#"><i class="fab fa-youtube  fa-2x text-success"></i></a>
      <a href="#"><i class="fab fa-facebook  fa-2x text-success"></i></a>
      <a href="#"><i class="fab fa-twitter fa-2x text-success"></i></a>
      <h1 ><u><strong>Upcoming courses</strong></u> </h1>
      <table class="table table-dark">
      <tbody>
        <tr><li>HTML </li></tr>
        <tr><li>CSS</li></tr>
        <tr><li>Javascript</li></tr>
        <tr><li>PHP</li></tr>
        <tr><li>MYSQL</li></tr>
        </tbody>
      </table>

    </div>
    <div class="col-sm-4 col-md-4 col-lg-4">
    <address>
      <h1><strong><u>Head office </u></strong></h1>
      <p>section 63 noida near utv park ,new Delhi</p>
      <h1><strong><u>Branch office</u></strong></h1>
        <p>section 63 noida near utv park ,new Delhi</p>
    </address>
    </div>
  </div>  

  </footer>
</div>
</body>
</html>