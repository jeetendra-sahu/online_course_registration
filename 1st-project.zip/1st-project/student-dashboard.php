<!DOCTYPE html>
<html>
<head>
	<title>Student Dashboard</title>

</head>
<?php  require "header.php"; ?>

  <?php  require "include.php"; ?>
<body>
<!-- start retrive profile data  
  <?php 

if (session_status() == PHP_SESSION_NONE ) {
    session_start();
}
 
if ( !(isset($_SESSION['id']))) {
  header("location:index.php");
}
 

   /*
      require "connection.php";
      $id=$_SESSION['id'];
      $sql="select * from signup where id= '$id'";
      $fire=mysqli_query($conn,$sql) or die("query not process ".mysqli_query($conn));
      if (mysqli_num_rows($fire)>0) {
        while($row=mysqli_fetch_assoc($fire))
         { */ 

   ?> 
   -->
  <!-- end retrive profile data  -->
<div class="container-fluid mt-5">
  <div class="row"> 
     
     <div class="col-3 border-right">
        <img src="image/profile.png" class="rouned mx-auto d-block" width="100">
    <nav>
    <div class="nav flex-column nav-pills " id="nav-tab" role="tablist">

     <a href="#TAB1" class="nav-item nav-link active " data-toggle="pill" role="tab" aria-selected="true">Dashboard</a>
    <a href="#TAB2" class="nav-item nav-link " data-toggle="pill" role="tab" aria-selected="false">purchased</a>
    <a href="#TAB3" class="nav-item nav-link " data-toggle="pill" role="tab" aia-selected="false" >course</a>
  <a href="#TAB4" class="nav-item nav-link " data-toggle="pill" role="tab" aia-selected="false" >Coupan Code</a>
  <a href="#TAB5" class="nav-item nav-link   " data-toggle="pill" role="tab" aia-selected="false" >profile</a>
  <a href="#TAB6" class="nav-item nav-link " data-toggle="pill" role="tab" aia-selected="false" >feedback form</a>

        </div>
    
      
    </nav>
     </div>


<div class="col-9" >
     <div class="tab-content">
   <!-- start dashboard -->
       <div class="tab-pane active"  role="tabpanel" aria-labelledby="tab" id="TAB1">
         <div class="text-center">
           <h1>welcome to Dashboard</h1>
         </div>
       </div>

<!--end dashboard -->
<!-- start purchase section -->
       <div class="tab-pane "  role="tabpanel" aria-labelledby="tab" id="TAB2">        
          <h1 class="text-center">Welcome to purchase section </h1>
          <hr>
          <div class="row">
                <div class="col-3">
                  <div class="card" style="width: 15rem;">
  <img src=" image/html.jpg" class="card-img-top" alt="html image">
   <h3 class="card-title">HTML Course</h3>
  <div class="card-body">
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
  <div class="card-footer"><a href="#" class="btn btn-info">purchase</a></div>
</div>
                </div>
                <div class="col-3">
                  <div class="card" style="width: 15rem;">
  <img src="image/css.jpg" class="card-img-top" alt=" css">
  <h3 class="card-title"> CSS course</h3>
  <div class="card-body">
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
  <div class="card-footer"><a href="#" class="btn btn-info">purchase</a></div>
</div>
                </div>
                <div class="col-3">
                <div class="card" style="width: 15rem;">
  <img src="image/mysql.jpg" class="card-img-top" alt="mysql ">
  <h3 class="card-title">Mysql course</h3>
  <div class="card-body">
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
<div class="card-footer"><a href="#" class="btn btn-info">purchase</a></div>
</div>
</div>
                <div class="col-3">
                  <div class="card" style="width: 15rem;">

  <img src="image/bootstrap.png" class="card-img-top" alt="bootstrapimage/">
   <h3 class="card-title">bootstrap course</h3>
  <div class="card-body">
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
  <div class="card-footer"><a href="#" class="btn btn-info">purchase</a></div>
</div>
                </div>
          </div>
                 
       </div>
<!-- end purchase -->
<!-- start courses -->
       <div class="tab-pane "  role="tabpanel" aria-labelledby="tab" id="TAB3">
            <div class="text-center"> 
                  <h1>Available courses</h1>
                  <div class="card mb-3">
                  <img src="image/html.jpg" class="card-img-top" alt="not set image" height="250">
                  <h1 class="card-title">HTML</h1>
                    <div class="card-body text-justify">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently  
                 
                    </div>
                    <div class="footer"><a class="btn btn-info" >purchase</a>  </div>
                   </div>
          </div>
       </div>
       <!-- end courses  -->

       <?php 
              require "connection.php";
              $sql="select * from coupan";
              $fire=mysqli_query($conn,$sql) or die("not slect from databse".mysqli_error($conn));
              $nor=mysqli_num_rows($fire); ?>
              
          <!-- start special offer -->
         <div class="tab-pane "  role="tabpanel" aria-labelledby="tab" id="TAB4">
              <div >
                <h1 class="text-center"> Available Coupan Code </h1>
                <table class="table">
                <thead>
                  <tr>
                    <th>Course</th>
                    <th>coupan code</th>
                    <th>% offer</th>
                    <th>Valit Till</th>
                  </tr>
                </thead>
                  <tbody> 
                  <?php 
                  if ($nor>0) {
                 while($row=mysqli_fetch_assoc($fire))
                 {

              

       
                          ?>
                    <tr>
                      <td> <?php echo $row['course']; ?></td>
                      <td><?php echo $row['code']; ?></td>
                      <td><?php echo $row['offer']."%"; ?></td>
                      <td><?php echo $row['valid'] ; ?></td>
                    </tr>
                    <?php 
                         }
              } ?>                    
                  </tbody>
                </table>
              </div>
         </div>
        <!-- end special offer  -->


        <!--               start profile                  -->

         <div class="tab-pane  "  role="tabpanel" aria-labelledby="tab" id="TAB5">
            <!-- start building profile  -->
               <nav>
         <div class="nav nav-pills" id="nav-tab" role="tablist">

           <a href="#profile1" class="nav-item nav-link active" data-toggle="pill" role="tab" aria-selected="true">view</a>
           <a href="#profile2" class="nav-item nav-link " data-toggle="pill" role="tab" aria-selected="false" >Update</a>
           
        </div>
        </nav>
     <?php 
                require "connection.php";
                $id=$_SESSION['id'];
                $sql="select * from signup where id='$id'";
                $fire=mysqli_query($conn,$sql) or die("not select DB ".mysqli_error($conn));
                $nor=mysqli_num_rows($fire);
                 if ($nor>0) {
                   $row=mysqli_fetch_assoc($fire);
                 ?> 


        <div class="tab-content">
          <div class="tab-pane active "  role="tabpanel" aria-labelledby="tab" id="profile1">

          <h1 class="text-center">View profile  </h1>
           <div id="viewdata">
                 <div class="row mt-3 p-2 border-bottom">
                   <div class="col-4">Name : <?php echo $row['name']; ?> </div>
                   <div class="col-4">Email :<?php echo $row['email']; ?> </div>
                   <div class="col-4">Mob : <?php echo $row['mobile']; ?> </div>
                 </div>
                  <div class="row mb-3 p-2 border-bottom">
                   <div class="col-4">DOB : <?php echo $row['dob']; ?></div>
                   <div class="col-4">Gender : <?php echo $row['gender']; ?> </div>
                   <div class="col-4">A/c Creation Date :<?php echo $row['creation_date']; ?> </div>
                 </div>
                  <div class="row mb-3 p-2 border-bottom">
                   <div class="col-4">
                   image :<img  src="image/<?php echo $row['image'];?>" width="100" height="150" >  </div>
                   
                   <div class="col-4 offset-md-4">others</div>
                 </div>
                 </div>
           </div>
           <?php  }
             
      ?>
           <div class="tab-pane "  role="tabpanel" aria-labelledby="tab" id="profile2">
             <h1 class="text-center"> Update Profile </h1>
                 
            <div id="updatedata">  
                      <table class="table">
  <thead>
     <th>Label</th>
     <th>update field</th>
     <th>currently set</th>
  </thead>
    <?php   
             require_once "connection.php";
             $id=$_SESSION['id'];
             $sql=" select * from signup where id='$id' ";
             $fire = mysqli_query($conn,$sql) or die(mysqli_error($conn));
             $row = mysqli_fetch_assoc($fire) or die(mysqli_error($conn));
               

     ?>
     <form>
  <tbody>
     <tr>
       <td>Name</td>
       <td><input type="text" name="name" class="from-control" value="<?php echo $row['name']; ?>"></td>
     </tr>
     <tr>
       <td>email</td>
       <td><input type="email" name="email" class="from-control" placeholder="Update email"> </td>
       <td><?php echo $row['email']; ?></td>
     </tr>
     <tr>
       <td>DOB</td>
       <td><input type="date" name="" class="from-control" value=""></td>
       <td><?php echo $row['dob']; ?></td>
     </tr>
     <tr>
       <td>mobile</td>
       <td><input type="number" name="" class="from-control" value="<?php echo $row['mobile']; ?>"></td>
     </tr>
     <tr>
       <td>Gender</td>
       <td>
           <input type="radio" name="gender" class="from-control" value="male"> male
           <input type="radio" name="gender" class="from-control" value="female"> female
           <input type="radio" name="gender" class="from-control" value="other"> other
        </td>
        <td><?php echo $row['gender']; ?></td>
     </tr>
     <tr>
       <td>image</td>
       <td>
       <input type="file" name="" class="from-control" ></td>
       <td><img  src="image/<?php echo $row['image'];?>" width="100" height="150" ></td>
     </tr>
     <tr>
       <td>Account Creation Date</td>
       <td><em><?php echo $row['creation_date']; ?></em></td>
     </tr>
     </tbody>
     <input type="hidden" name="id" value="<?php echo $id; ?>">
     </form>
</table>
           </div>

           </div>
         </div>
     
   

       </div>
       <!--end profile  -->
       <!-- feedback form -->
        <div class="tab-pane "  role="tabpanel" aria-labelledby="tab" id="TAB6">
        <h1 class="text-center">Please fill feedback form </h1>
         <form>
           <table class="table">
             <tr>
               <td>about</td>
              <td>
              <select class="form-control" id="sel1">
                      <option>courses</option>
                      <option>purchase</option>
                      <option>payment</option>
                      <option>teaching</option>
                      <option>other</option>
              </select>
              </td>
               </tr>
               <tr>
                 <td>suggestion</td>
               <td><textarea class="form-control" rows="5" id="comment" placeholder="query max 100 word"></textarea></td>
             </tr>
             <tr>
               <td></td>
               <td>
                  <input type="submit" name="submit" class="btn btn-info">    
               </td>
             </tr>
           </table>
         </form>
       </div>


     </div>
</div>
 
</div>
<br><br>
<?php include "footer.php"; ?>
</div>

</body>
</html>