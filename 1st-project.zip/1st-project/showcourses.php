<!DOCTYPE html>
<html>
<head>
	<title>showcorses.php</title>
<?php require_once "include.php"; ?>
</head>
<body>
<?php require_once "header.php"; ?>
<style type="text/css">
	 #more {display: none;}
</style>
  
  <?php  require_once "connection.php";
       $sql="select * from availablecourses";
       $fire=mysqli_query($conn,$sql) or die(mysqli_error($conn));
       
       while ($row=mysqli_fetch_assoc($fire)) {
        
     

   ?>
<div class="container-fluid">
	<div class="course-container">
		<div class="row mt-5">
			
			<div class="col-sm-6">
			<h3 class="text-center">HTML FULL COURSE</h3>
<p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae scperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae sctae sctae sctae scel<span id="dots">...</span><span id="more">erisque enim ligula venenatis dolor. Maecenas nisl est, ultrices nec congue eget, auctor vitae massa. Fusce luctus vestibulum augue ut aliquet. Nunc sagittis dictum nisi, sed ullamcorper ipsum dignissim ac. In at libero sed nunc venenatis imperdiet sed ornare turpis. Donec vitae dui eget tellus gravida venenatis. Integer fringilla congue eros non fermentum. Sed dapibus pulvinar nibh tempor porta.</span>
<span><a href="#" onclick="myFunction()" id="myBtn">Read more</a href="#"></span></p>
<script type="text/javascript">
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more";
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less";
    moreText.style.display = "inline";
  }
}
</script>

			</div>
            <div class="col-sm-6">
				<img src="image/<?php echo $row['image']; ?>" class="img-fluid" width="100%">
			</div>

		</div>
         <div class="row mt-2">
         	<div class="col-sm-4 offset-sm-1">
              <table class="table">
                <tbody>
      <tr><td>course name</td><td>=></td><td><?php echo $row['name']; ?></td></tr>
      <tr><td>course duration</td><td>=></td><td><?php echo $row['duration']; ?></td></tr>
      <tr><td>price </td><td>=></td><td><?php echo $row['price']; ?></td></tr>
      <tr><td>instructor</td><td>=></td><td><?php echo $row['teacher']; ?></td></tr>
      <tr><td>already enroll</td><td>=></td><td>12,251</td></tr>
      <tr><td>mode</td><td>=></td><td><?php echo $row['mode']; ?></td></tr>
         		</tbody>
         		</table>
         	</div>
         	<div class="col-sm-7" id="ads"></div>
         </div>

	</div>
     <div class="comment-section">
     	<div class="row">
     		
     	</div>
     </div>
     
</div>
<hr>
<?php  }   ?>

<?php require_once "footer.php"; ?>

</body>
</html>