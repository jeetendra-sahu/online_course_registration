<!DOCTYPE html>
<html>
<head>
	<title>Student Login </title>
</head>
<body>

<?php require "header.php"; 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
 
if (isset($_SESSION['id'])) {
  header("location:index.php");
}

 ?>


<div class="login-container" style="margin-top: 40px;"> 
     <div class="head"> Student Login </div>


     <div class="getdata">
<form action="login.php" method="post">
          <input type="email" class="userdata"  name="username" placeholder="Enter username" required> 
          <input type="password" class="userdata"  name="password" placeholder="Enter password" required>
          <br>
  
        <center>
                 <input type="checkbox" name="check" class="fc userdata" required> Remember me 
                 <a href="#" class="fc userdata" style="color: blue;">Forgot Password</a><br>
                 <input type="submit" name="submit" value="Login">
        </center>
</form>
     </div>

<div>
<?php 
   
  if (isset( $_POST["submit"])) {


    $username=$_POST["username"] ;
    $password= $_POST["password"] ;
    $check=$_POST["check"] ;

   // connection file 
    require "connection.php"; 
// start account check 
    if (!empty($username) && !empty($password)) {
    $password=md5($password);
   $sql="select * from login where email='$username' and password='$password'";
   $result=mysqli_query($conn,$sql) or die("not processed query 1 " . mysqli_query($conn));
    if (mysqli_num_rows($result)>0) 
    {
        while ($row=mysqli_fetch_assoc($result))
             {
                 $_SESSION["id"]=$row["id"];
                 $_SESSION["email"]= $row["email"];
                 $_SESSION["password"]= $row["password"]; 
                 header("location:student-dashboard.php") or die("sesstion problem");                
               }
}
else
echo "Invalid username or password"; 
}
echo "empty password not allow ";

}
 ?>


</div>
 </div>
</body>
</html>