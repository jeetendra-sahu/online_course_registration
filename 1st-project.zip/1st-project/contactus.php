<!DOCTYPE html>
<html>
<head>
	<title>contact us</title>
	
</head>
<body >
<?php require "include.php"; ?>
<div>

<?php require "header.php" ;

if (isset($_POST['submit'])) {
	?> <br><br>
	 
	<?php 
     $c1= $_POST['name'];
     $c2= $_POST['email'];
     $c3= $_POST['mobile'];
     $c4= $_POST['qeury'];

      require "connection.php";
      $sql="insert into contactus(name,email,mobile,query) values('$c1','$c2','$c3','$c4')"; 

      $fire= mysqli_query($conn,$sql) or die("query not processing".mysqli_error($conn)) ;

      if($fire==true)
      {
      	echo "<h3>your query is taken we respond you soon <a href='student-dashboard.php'>click here</a> to go dashboard</h3>";
      }


 
   } 



?>

</div>

</body>
</html>