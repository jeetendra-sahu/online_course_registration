<!DOCTYPE html>
<html>
<head>
	<title>test.php</title>
   <?php  require_once "include.php"; ?> 
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >     
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	 
</head>


 <!--  Code and explanation of user_registration.php  -->

<?php/*
//connection established
$con = mysqli_connect("localhost","root","","ecommerce") or die(mysqli_error($con));

//Store form values into variables
$email = $_POST['email'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$phone = $_POST['phone'];

//Store insert query in a variable. Use double quotes to let PHP treat variables as variables only.
$user_registration_query = "insert into users(email, first_name, last_name, phone) values ('$email', '$first_name', '$last_name', '$phone')";

//Execute the query
$user_registration_submit = mysqli_query($con, $user_registration_query) or die(mysqli_error($con));

//If this echo is executed, this means query successfully executed. Otherwise, die function with mysqli_query function would have stopped the execution of the code.
echo "User successfully inserted"; */

?>



<?php 

$conn=mysqli_connect("localhost","root","","ecommerce") or die("not able to connecting");
   
  $r=mysqli_insert_id($conn);
  echo $r;
die("end of code");
?>
<div class="container">
<div class="row"> 
<div class="col-sm-4 offset-sm-4">
       <div class="panel panel-primary">
         <div class="panel-heading" >User form</div>
         <div class="panel-body">
           <form>
               <div class="form-group">
                  <label>Email</label>
                  <input type="text" name="name" class="form-control">
               </div>

               <div class="form-group">
                  <label>First Name</label>
                  <input type="text" name="name" class="form-control">
               </div>

               <div class="form-group">
                  <label>Last Name</label>
                  <input type="text" name="name" class="form-control">
               </div>

               <div class="form-group">
                  <label>Phone no</label>
                  <input type="text" name="name" class="form-control">
               </div>
               <input type="submit" name="submit" class="btn btn-primary" >
           </form>
         </div>
         <div class="panel-footer"> Forgot password ?</div>
       </div>
</div>
</div> 
</div>
 <br>


 <?php 

$variable1 = "10";
$variable2 = "5";
 
 $number1 = 10;
echo 'The number is $number1.';
   $v=12;
   echo 'number is $v';
$array = array("first_number"=> 1);
echo $array['First_number'];

  function divide($parameter1, $parameter2){
  $division = $parameter1 / $parameter2;
  return $division;
}
divide(12,4);
echo "Division of two numbers is ".$division."<br>";

  $marks=array("first_number"=>23,"second_number"=>34,"third_number"=>24);
  foreach ($marks as $key=>$value) {
    echo "this is "."$key"."and value is ".$value."<br>";
  }
  echo "<br>";
  $marks=array(1,2,3,4,5,6,7,8,9,10);
  foreach ($marks as $value) {
    echo $value ." ";  


  }

 echo 5 ** 2 ."<br>";
$text="i like progamming";
print_r(explode(" ", $text));
$star=  array("pen","pencil","eraser",);
echo implode("-", $star);  

 ?>


<body>






























 <?php  require "test2.php"; ?> 
<div class="container">
  

 
<?php 
        if (isset($_SESSION['message'])):   ?>
        <div class="alert alert-<?=$_SESSION['msg_type']?>">
        <?php
           echo $_SESSION['message'];
           unset($_SESSION['message']);
        ?>
          
        </div>    
         
      <?php  endif ?>
   <div class="table-d">
     <table class="table">
       <thead>
         <tr>
           <th>id</th>
           <th>Name</th>
           <th>Location</th>
           <th>Action</th>
         </tr>
       </thead>
       <tbody>
<?php 
       $con=new mysqli('localhost','root','','test') or die("not connected");
       $sql=$con->query("select * from test") or die($con->error);
        while ($row=$sql->fetch_assoc()) {
          
       

 ?>
         <tr>
           <td><?php  echo $row['id']  ;?></td>
           <td><?php echo  $row['name'] ; ?></td>
           <td><?php echo  $row['location'] ; ?></td>
           <td>
             <a  href="test2.php?edit=<?php echo  $row['id'] ; ?>" name="edit" class="btn btn-info">edit</a>
             <a href="test2.php?delete=<?php echo  $row['id'] ; ?>" name="delete" class="btn btn-danger" >delete</a>
           </td>
         </tr>
       <?php  } ?>
       </tbody>
     </table>
   </div>
  <div class="col-sm-4 offset-sm-4">
    <form action="test2.php" method="post" >
    <p class="h1">Add to database</p>
      <div class="form-group">
       <input type="text" class="form-control" name="name" 
        value="<?php echo $name; ?>" placeholder="name" >
      </div>

      <div class="form-group">
    <input type="text" class="form-control" name="location"         value="<?php echo $location; ?>" placeholder="address" >
      </div>
      <div class="form-group">
        <button class="btn btn-primary" type="submit"  name="submit">Submit</button>
 
      </div>
    </form>
 
  </div>




</div>
<h1>Scrollspy</h1>
<div id="list-example" class="list-group">
  <a class="list-group-item list-group-item-action" href="#list-item-1">Item 1</a>
  <a class="list-group-item list-group-item-action" href="#list-item-2">Item 2</a>
  <a class="list-group-item list-group-item-action" href="#list-item-3">Item 3</a>
  <a class="list-group-item list-group-item-action" href="#list-item-4">Item 4</a>
</div>

<div data-spy="scroll" data-target="#list-example" data-offset="1" class="scrollspy-example">
  <h4 id="list-item-1">Item 1</h4>
  <p>
  nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fu
  </p>
  <h4 id="list-item-2">Item 2</h4>
  <p>nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra  at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante soitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fu</p>
  <h4 id="list-item-3">Item 3</h4>
  <p>nibh libero, in grav at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante som in vulputate at, tempus viverra turpis. Fu</p>
  <h4 id="list-item-4">Item 4</h4>
  <p>nibh libero, in gravida nul at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante so at, tempus viverra turpis. Fu vestibulum in vulputate at, tempus viverra turpis. Funibh libero, in gravida nulla. Nulla vel metus scelerisque ante som in vulputate at, tempus viverra turpis. Fu</p>
</div>

<h2>end scrollspy</h2>

<h1> learn media object</h1>
<div class="media">
  <img src="image/css.jpg" class="mr-3" alt="css image">
  <div class="media-body">
    <h5 class="mt-0">Media heading</h5>
    Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
  </div>
</div>

<h1> session ckeck</h1>

  <div>
  	<h1>retrive data from database </h1>
  	<?php   
     require 'connection.php'; 
     if (isset($_POST['submit'])) {
       $name=$_POST['name'];
       if (!empty($name)) 
       {
    $sql="select id from test where name ='$name'";
      $fire=mysqli_query($conn,$sql) or die("not done query 1".mysqli_query($conn));       
      if(mysqli_num_rows($fire)>0)
      {
        echo "name already exist : try another name";
      }
      else
      {
    
        $sql="insert into test(name) values('$name')";
        $fire=mysqli_query($conn,$sql) or die("not done query 2");
        if ($fire==TRUE) {
          echo "data inserted : ";
        }
        else
        {
          echo "not inserted : ";
        }

      }
      }
      else
        echo "empty field not allowed";
      }
  	?>
    <form action="test.php" method="post" >
         <input type="text" name="name" ><br>
         <input type="submit" name="submit" value="insert">

    </form>

  </div>
  <div>
    <?php 
          $i=1;
             while ( $i<= 10) {
              ?>
              <h1> Value of i = <?php echo $i; $i++;?>   </h1>
              <?php 
             }


     ?>
  </div>
</body>
</html>