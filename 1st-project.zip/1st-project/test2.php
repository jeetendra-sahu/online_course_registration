<?php
include 'include.php'; 
?>
<style type="text/css">
  #more {display: none;}
</style>
  <form action="" method="post">
    <input type="text" name="fname" pattern="[A-Za-z]{3}" title="only three latter are allow "><br><br>
    <input type="text" name="lname" pattern="[A-Za-z]{3,}" title="capital latter or above three latter"><br><br>
    <input type="password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="must contain atlest one lowercase or one upercase or one numericals"><br><br>
    <input type="submit" name="submit">
  </form>
  <?php
  if (isset($_POST['submit'])) {
     echo"your data is ". $_POST['fname'];
     echo $_POST['lname'];
     echo "<br>password is ".$_POST['password'];
  }
  ?>


<?php die(); ?>
<div class="jumbotron">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas vitae sctae sctae sctae sctae sctae sctae sctae scel<span id="dots">...</span><span id="more">erisque enim ligula venenatis dolor. Maecenas nisl est, ultrices nec congue eget, auctor vitae massa. Fusce luctus vestibulum augue ut aliquet. Nunc sagittis dictum nisi, sed ullamcorper ipsum dignissim ac. In at libero sed nunc venenatis imperdiet sed ornare turpis. Donec vitae dui eget tellus gravida venenatis. Integer fringilla congue eros non fermentum. Sed dapibus pulvinar nibh tempor porta.</span>
<span><a href="#" onclick="myFunction()" id="myBtn">Read more</a href="#"></span></p>
<script type="text/javascript">
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more";
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less";
    moreText.style.display = "inline";
  }
}
</script>
</div>

<br><br><br>




<div class="accordion" id="accordionExample">
  
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor,
        <span id="collapseOne" class="collapse hidden" aria-labelledby="headingOne" data-parent="#accordionExample">
    <span class="card-body">sunt aliqua put a bird on it squid single-origin coffee  nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </span>
    </span>
  <span id="headingOne"><button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          read more
        </button>
  </span>
 
  <!--
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h2 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Collapsible Group Item #2
        </button>
      </h2>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h2 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Collapsible Group Item #3
        </button>
      </h2>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div> -->
</div>


<?php 
die();
$con=new mysqli('localhost','root','','test') or die("not connected");
 session_start();

$name='';
$location='';
$id='';
/*

    if (isset($_POST['submit'])) {
    	$name=$_POST['name'];
    	$location=$_POST['location'];
      //	echo "the name is ".$name."<br>"."the location is".$location;
       $sql=$con->query("insert into test(name,location) values('$name','$location')") or die($con->error);
         $_SESSION['message']="record has been saved!";
       $_SESSION['msg_type']="success";
       header("location:test.php");

    }
 
if (isset($_GET['delete'])) {
	 $id=$_GET['delete'];
	 $sql=$con->query("delete from test where id='$id'") or die($con->error);
	 
	  $_SESSION['message']="record has been Deleted!";
       $_SESSION['msg_type']="danger";   
       header("location:test.php");


}
*/
/*
if (isset($_GET['edit'])) {
	 $id=$_GET['edit'];
	 $sql=$con->query("select * from test where id='$id'") or die($con->error);
	  if (count($sql)==1) {

	  	$row=$sql->fetch_assoc();
	  	$name=$row['name'];
	  	$location=$row['location'];
	  }
        
}

 */



 ?>


<div class="container">    
   <div class="table-d">
     <table class="table">
       <thead>
         <tr>
           <th>id</th>
           <th>Name</th>
           <th>Location</th>
           <th>Action</th>
         </tr>
       </thead>
       <tbody>
<?php 
       $con=new mysqli('localhost','root','','test') or die("not connected");
       $sql=$con->query("select * from test") or die($con->error);
        while ($row=$sql->fetch_assoc()) {
 
 ?>
         <tr>
           <td><?php  echo $row['id']  ;?></td>
           <td><?php echo  $row['name'] ; ?></td>
           <td><?php echo  $row['location'] ; ?></td>
           <td>
             <a  href="test2.php?edit=<?php echo  $row['id'] ; ?>" name="edit" class="btn btn-info">edit</a>
             <a href="test2.php?delete=<?php echo  $row['id'] ; ?>" name="delete" class="btn btn-danger" >delete</a>
           </td>
         </tr>
       <?php  } ?>
       </tbody>
     </table>
   </div>
<?php  
      if (isset($_GET['edit'])) {
    $id=$_GET['edit'];
   $sql=$con->query("select * from test where id='$id'") or die($con->error);
    if (count($sql)==1) {
      $row=$sql->fetch_assoc();
      $name=$row['name'];
      $location=$row['location'];
      
 
       }  }  
 ?>
  <div class="col-sm-4 offset-sm-4">
    <form action="test2.php" method="post" >
    <p class="h1">update record</p>
      <div class="form-group">
           <input type="text" class="form-control" value="<?php echo $name; ?>" name="name" placeholder="Enter Name" >
      </div>

      <div class="form-group">
          <input type="text" class="form-control" value="<?php echo $location; ?>" name="location"  placeholder="Enter location" >
      </div>
      <input type="hidden" name="id" value="<?php echo $id; ?>">
     
      <div class="form-group">
         <button type="submit" name="submit" class="btn btn-info">update</button>
      </div>
    </form>
 
  </div>
</div>   
  
<?php

   if (isset($_POST['submit'])) {
       $id=$_POST['id'];
     $name=$_POST['name'];
     $location=$_POST['location'];
     $sql=$con->query("update test set name = '$name', location='$location' where id ='$id' ") or die($con->error);
     if ($sql==true) {
       echo "updated successfully";
     }
     else 
     {
      echo "not successfully";
     }
   }

   ?>