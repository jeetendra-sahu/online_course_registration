<!DOCTYPE html>
<html>
<head>
	<title>Admin Panel</title>
 <?php require "include.php"; ?> 
 <style type="text/css">
   body{
    padding-right: relative;
    background-image: url("image/admin_ back.jpg");
    margin-top: auto;
    height: auto;
   }
#adminform
{
  position: absolute;
    
    margin-left: 40%;
    margin-top: 15%;
      

}
</style>
</head>
 <body>
 <div class="text-center" style="width: 20rem;" id="adminform">
      <h1 class="text-light"> Admin Login</h1>  
    <form  >

  <div class="form-group">
<!-- user part -->
   <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon1"><i class="fa fa-user"></i></span>
  </div>
  
  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp " placeholder="Enter email adress">
    </div>  
  </div>


<!--  password part--> 

  <div class="form-group">
  <div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon1"><i class="fa fa-key"></i></span>
  </div>
   <!--  submit button--> 
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter password">
</div>

  </div>

  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Remember me</label>
    <a href="#" > forgot Password </a>
  </div>
  
      <button type="submit" class="btn btn-primary">Login as admin </button>
    </form>
   </div>
 </body>
</html>