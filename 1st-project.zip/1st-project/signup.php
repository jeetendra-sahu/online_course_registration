<!DOCTYPE html>
<html>
<head>
	<title>Student Sign Up</title>
</head>
<body>
<?php require "header.php";

//  start to check already login 

  if(isset($_SESSION['id']) &&  isset($_SESSION['email']) && isset($_SESSION['password']))
            {
              header("location:index.php") or die("allow to redirect to index.php");
            }


 ?>



<div class="signup-container" style="margin-top: 40px;"> 
     <div class="head"> Student Sign up</div>


     <div class="Signup" >
<form action="signup.php" method="post">  
          <input type="text" class="userdata"  name="name"  placeholder="Enter full name" required> 
          <input type="email" class="userdata"   name="email"  placeholder="Enter email address" required>
          <input type="password" class="userdata"   name="password1" placeholder="Enter password" required>
          <input type="password" class="userdata"   name="password2" placeholder="Enter confirm password" required>
          <input type="number" class="userdata"     name="mobile"  placeholder="Enter mobile number" required>
          
          <br>
  
     <center>
        
        <input type="submit" name="submit" class="btn btn-info" value="Login">
</center>
 </form>
     </div>

<?php 

if (isset($_POST['submit'])) 
{
     require "connection.php";
     $name=$_POST["name"];
     $email=$_POST["email"];
     $password1=$_POST["password1"];
     $password2=$_POST["password2"];
     $mobile=$_POST["mobile"];

     if (($password1==$password2) && !empty($password1) && !empty($password2)) 
     {
         
         $password1=md5($password1);
           
           $sql="select id from signup where email = '$email' or mobile='$mobile'";
            $result=mysqli_query($conn,$sql) or die("query is not done mysqli_query ".mysql_query($conn));
            
            
           if (mysqli_num_rows($result)>0)
            {

                echo "This mobile number or email already register";
           }
           else
           {
               $sql=" insert into signup (name,email,password,mobile) values('$name','$email','$password1','$mobile') ";

                    $result=mysqli_query($conn,$sql) or die("not done query 2 ".mysqli_query($conn));
                    if ($result==TRUE) {
                         echo "congratulations account has been created ";
                         $sql="insert into login(email,password) values('$email','$password1')";
                         $result=mysqli_query($conn,$sql) or die("not inserted in login table".mysqli_query($conn));
                    }
                    else
                    {
                         echo "problem in query 2 ";
                    }
           }
     }
     else 
     {
          echo "<br> password does not match";
     }
      

}
  
 ?> 

</div>

</body>
</html>