<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
</head>
<body>
<?php 

require "include.php"; 
require "header.php"; 

if(isset($_SESSION['id']) &&  isset($_SESSION['email']) && isset($_SESSION['password']))
            {
              header("location:index.php") or die("allow to redirect to index.php");
            }


?>

<div class="signup-container"> 
     <div class="head"> Forgot Password </div>


     <div class="Signup">
      <form> 
          
          <input type="email" class="userdata"  name="email" placeholder="Enter email address" required>
          
          
          <input type="number" class="userdata"  name="mob" placeholder="Enter Enter mobile number" required>
          
          <br>
  
     <center>
        
        <input type="submit" name="submit" value="submit">
</center>
</form>
     </div>
</div>
</body>
</html>